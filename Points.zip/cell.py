from enum import Enum


class Cell(Enum):
    RED = 1
    BLUE = 2
    EMPTY = 3
    BLACK = 4
